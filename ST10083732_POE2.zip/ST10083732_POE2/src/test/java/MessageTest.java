import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.mycompany.poe1.Message;

public class MessageTest {

    @BeforeEach
    public void resetBeforeEach() {
        // This clears the message list between tests if needed.
        // Optional: Add a static reset method in Message class to clear sentMessages.
    }

    @Test
    public void testSendTwoMessagesAndVerify() {
        // Message 1
        String id1 = "msg001";
        String recipient1 = "0821234567";
        String content1 = "Hi Mike, can you join us for dinner tonight";
        Message msg1 = new Message(id1, recipient1, content1);

        assertTrue(msg1.checkMessageID(), "Message ID should be valid (≤ 10 chars)");
        assertTrue(msg1.checkRecipientCell(), "Recipient number should be valid (≤ 10 chars and starts with 0)");
        assertNotNull(msg1.createMessageHash(), "Hash should be generated");

        msg1.SentMessage(); // Assume input is mocked to select '1' for Send

        // Message 2
        String id2 = "msg002";
        String recipient2 = "0834567890";
        String content2 = "Reminder: Meeting at 3PM";
        Message msg2 = new Message(id2, recipient2, content2);

        assertTrue(msg2.checkMessageID());
        assertTrue(msg2.checkRecipientCell());
        assertNotNull(msg2.createMessageHash());

        msg2.SentMessage();

        // Total Messages Sent
        int total = Message.returnTotalMessages();
        assertEquals(2, total, "Should have 2 messages sent");

        // Print all messages
        String allMessages = Message.printMessages();
        assertTrue(allMessages.contains("Hi Mike") && allMessages.contains("Reminder"), "All messages should be listed");
    }
}
