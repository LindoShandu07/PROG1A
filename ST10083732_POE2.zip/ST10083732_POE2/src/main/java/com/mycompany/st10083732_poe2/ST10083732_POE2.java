package com.mycompany.st10083732_poe2;

import java.util.ArrayList;
import java.util.Scanner;

public class ST10083732_POE2{

    public static void main(String[] args) {
        // Input
        try (Scanner scanner = new Scanner(System.in)) {
            // Input
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            
            System.out.print("Enter South African phone number (e.g., 0821234567): ");
            String phoneNumber = scanner.nextLine();
            
            System.out.println();
            
            boolean isUsernameValid = isValidUsername(username);
            boolean isPasswordValid = isValidPassword(password);
            boolean isPhoneValid = isValidPhoneNumber(phoneNumber);
            
            if (isUsernameValid) {
                System.out.println("Username successfully captured.");
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
            
            if (isPasswordValid) {
                System.out.println("Password successfully captured.");
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
            
            if (isPhoneValid) {
                System.out.println("Phone number successfully captured.");
            } else {
                System.out.println("Phone number is not correctly formatted; please ensure it starts with 0 and contains exactly 10 digits.");
            }
            
            if (isUsernameValid && isPasswordValid && isPhoneValid) {
                System.out.println("\nWelcome to QuickChat.");
                
                ArrayList<String> messages = new ArrayList<>();
                boolean running = true;
                
                while (running) {
                    System.out.println("\nPlease select an option:");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show Recently Sent Messages");
                    System.out.println("3) Quit");
                    
                    String choice = scanner.nextLine();
                    
                    switch (choice) {
                        case "1":
                            System.out.print("How many messages would you like to enter? ");
                            int msgCount = Integer.parseInt(scanner.nextLine());
                            
                            for (int i = 0; i < msgCount; i++) {
                                System.out.print("Enter recipient name: ");
                                String recipient = scanner.nextLine();
                                
                                System.out.print("Enter your message: ");
                                String content = scanner.nextLine();
                                
                                messages.add("To: " + recipient + " | Message: " + content);
                            }
                            break;
                            
                        case "2":
                            System.out.println("Coming Soon.");
                            break;
                            
                        case "3":
                            running = false;
                            System.out.println("Thank you for using QuickChat!");
                            break;
                            
                        default:
                            System.out.println("Invalid choice. Please try again.");
                            break;
                    }
                }
            } else {
                System.out.println("\nLogin failed. Please check your details.");
            }
        }
    }

    // Username must contain underscore and be no more than 5 characters
    public static boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Password rules: 8+ chars, 1 capital letter, 1 number, 1 special character
    public static boolean isValidPassword(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    // South African number: must be 10 digits, start with 0
    public static boolean isValidPhoneNumber(String phone) {
        return phone.matches("0\\d{9}");
    }
}
