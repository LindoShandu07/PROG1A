package com.mycompany.poe1;

import java.util.ArrayList;
import java.util.Scanner;

public class Message {

    private final String messageID;
    private final String recipientCell;
    private final String messageContent;
    private static final ArrayList<String> sentMessages = new ArrayList<>();

    // Constructor
    public Message(String messageID, String recipientCell, String messageContent) {
        this.messageID = messageID;
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
    }

    // 1. checkMessageID()
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // 2. checkRecipientCell()
    public boolean checkRecipientCell() {
        return recipientCell.length() <= 10 && recipientCell.startsWith("0");
    }

    // 3. createMessageHash()
    public String createMessageHash() {
        return Integer.toHexString((messageID + recipientCell + messageContent).hashCode());
    }

    // 4. SentMessage() - let user choose to send/store/disregard
    public String SentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose what to do with the message:");
        System.out.println("1. Send");
        System.out.println("2. Store");
        System.out.println("3. Disregard");

        String choice = scanner.nextLine();
        switch (choice) {
            case "1" -> {
                sentMessages.add("To: " + recipientCell + " | Message: " + messageContent);
                return "Message sent.";
            }
            case "2" -> {
                return "Message stored for later.";
            }
            case "3" -> {
                return "Message disregarded.";
            }
            default -> {
                return "Invalid option.";
            }
        }
    }

    // 5. printMessages()
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }

        StringBuilder builder = new StringBuilder();
        for (String msg : sentMessages) {
            builder.append(msg).append("\n");
        }
        return builder.toString();
    }

    // 6. returnTotalMessages()
    public static int returnTotalMessages() {
        return sentMessages.size();
    }

}
